import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-standard',
  templateUrl: './standard.component.html',
  styleUrls: ['./standard.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class StandardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
