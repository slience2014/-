export class Message {
  usrname:string;
  id: string;
  idcard: string;
  email:string;
  phonenumber: string;
  text: string;
  usrrank: string;
}
