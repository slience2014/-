export class Usr{
  id: string;
  idcard: string;
  phonenumber: string;
  usrrank: number;


}
