import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.css','../../../node_modules/bootstrap/dist/css/bootstrap.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class ReservationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
