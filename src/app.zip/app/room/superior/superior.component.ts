import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-superior',
  templateUrl: './superior.component.html',
  styleUrls: ['./superior.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SuperiorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
