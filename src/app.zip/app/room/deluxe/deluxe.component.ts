import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-deluxe',
  templateUrl: './deluxe.component.html',
  styleUrls: ['./deluxe.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DeluxeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
